//! Scratch check: a modified copy of the core must reproduce every game vector's Outcome (or
//! error code) and its traceKeccak, the keccak256 of the per-tick state hashes.
use jiro_core::hash::state_hash;
use jiro_core::keccak::keccak256;
use jiro_core::replay::replay_observed;

fn unhex(s: &str) -> Vec<u8> {
    (0..s.len() / 2).map(|i| u8::from_str_radix(&s[2 * i..2 * i + 2], 16).unwrap()).collect()
}

fn main() {
    let text = std::fs::read_to_string(std::env::args().nth(1).unwrap()).unwrap();
    let (mut ok, mut bad) = (0, 0);
    for line in text.lines() {
        let f: Vec<&str> = line.split('\t').collect();
        let (name, level, journal, weight) = (f[0], unhex(f[1]), unhex(f[2]), f[3].parse::<u16>().unwrap());
        let mut trace = Vec::new();
        let result = replay_observed(&level, &journal, weight, |game| trace.extend(state_hash(game)));
        let got = match result {
            Ok(o) => format!("ok:{}:{}:{}:{}", o.ticks_used, o.claim_bp, o.level_score, o.end_reason as u8),
            Err(e) => format!("err:{}", e.code()),
        };
        let trace_keccak: String = keccak256(&[&trace]).iter().map(|b| format!("{b:02x}")).collect();
        if got == f[4] && trace_keccak == f[5] {
            ok += 1;
        } else {
            bad += 1;
            println!("MISMATCH {name}: got {got} {trace_keccak}, expected {} {}", f[4], f[5]);
        }
    }
    println!("{ok} vectors reproduce their Outcome or error and their traceKeccak; {bad} mismatches");
}
