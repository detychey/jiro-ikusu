//! Scratch bare-metal RV32IM wrapper around jiro_core::replay, for instruction counting only.
#![no_std]
#![no_main]

use core::panic::PanicInfo;

#[panic_handler]
fn panic(_: &PanicInfo) -> ! {
    unsafe { core::arch::asm!("ebreak", options(noreturn)) }
}

/// a0 = level ptr, a1 = level len, a2 = journal ptr, a3 = journal len, a4 = weightBp.
/// Halts with ecall: a0 = replay code (0 ok), a1 = ticks used, a2 = claim bp, a3 = level score,
/// a4 = end reason.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn _start(
    level: *const u8,
    level_len: usize,
    journal: *const u8,
    journal_len: usize,
    weight: u32,
) -> ! {
    let level = unsafe { core::slice::from_raw_parts(level, level_len) };
    let journal = unsafe { core::slice::from_raw_parts(journal, journal_len) };
    let (code, ticks, claim, score, end) = match jiro_core::replay::replay(level, journal, weight as u16) {
        Ok(outcome) => (
            0u32,
            u32::from(outcome.ticks_used),
            u32::from(outcome.claim_bp),
            outcome.level_score,
            outcome.end_reason as u32,
        ),
        Err(error) => (u32::from(error.code()), 0, 0, 0, 0),
    };
    unsafe {
        core::arch::asm!("ecall", in("a0") code, in("a1") ticks, in("a2") claim, in("a3") score, in("a4") end, options(noreturn))
    }
}
