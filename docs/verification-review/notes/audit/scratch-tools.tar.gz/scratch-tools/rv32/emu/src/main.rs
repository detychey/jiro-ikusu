//! Scratch RV32IM interpreter: loads a static ELF, runs `_start(level, len, journal, len, weight)`
//! until `ecall`, and counts executed instructions per pc. One instruction = one count.
use std::collections::BTreeMap;
use std::io::Write;

const MEM: usize = 16 << 20;
const LEVEL_AT: u32 = 0x0080_0000;
const JOURNAL_AT: u32 = 0x0081_0000;
const STACK_TOP: u32 = 0x00F0_0000;

fn rd32(b: &[u8], o: usize) -> u32 { u32::from_le_bytes([b[o], b[o + 1], b[o + 2], b[o + 3]]) }
fn rd16(b: &[u8], o: usize) -> u16 { u16::from_le_bytes([b[o], b[o + 1]]) }

struct Machine { mem: Vec<u8>, x: [u32; 32], pc: u32, text_lo: u32, text_hi: u32, hist: Vec<u64>, min_sp: u32 }

fn load(elf: &[u8]) -> Machine {
    assert_eq!(&elf[0..4], b"\x7fELF");
    assert_eq!(elf[4], 1, "ELF32");
    let entry = rd32(elf, 24);
    let phoff = rd32(elf, 28) as usize;
    let phentsize = rd16(elf, 42) as usize;
    let phnum = rd16(elf, 44) as usize;
    let mut mem = vec![0u8; MEM];
    let (mut lo, mut hi) = (u32::MAX, 0u32);
    for i in 0..phnum {
        let p = phoff + i * phentsize;
        if rd32(elf, p) != 1 { continue; }
        let (off, vaddr, filesz, memsz, flags) = (rd32(elf, p + 4) as usize, rd32(elf, p + 8), rd32(elf, p + 16) as usize, rd32(elf, p + 20), rd32(elf, p + 24));
        mem[vaddr as usize..vaddr as usize + filesz].copy_from_slice(&elf[off..off + filesz]);
        if flags & 1 != 0 { lo = lo.min(vaddr); hi = hi.max(vaddr + memsz); }
    }
    let n = ((hi - lo) / 4) as usize + 1;
    Machine { mem, x: [0; 32], pc: entry, text_lo: lo, text_hi: hi, hist: vec![0; n], min_sp: STACK_TOP }
}

impl Machine {
    fn r8(&self, a: u32) -> u8 { self.mem[a as usize] }
    fn r16(&self, a: u32) -> u16 { rd16(&self.mem, a as usize) }
    fn r32(&self, a: u32) -> u32 { rd32(&self.mem, a as usize) }
    fn w8(&mut self, a: u32, v: u8) { self.mem[a as usize] = v; }
    fn w16(&mut self, a: u32, v: u16) { self.mem[a as usize..a as usize + 2].copy_from_slice(&v.to_le_bytes()); }
    fn w32(&mut self, a: u32, v: u32) { self.mem[a as usize..a as usize + 4].copy_from_slice(&v.to_le_bytes()); }

    /// Runs to the first ecall and returns the instruction count.
    fn run(&mut self) -> u64 {
        let mut count: u64 = 0;
        loop {
            let pc = self.pc;
            assert!(pc >= self.text_lo && pc < self.text_hi, "pc {pc:#x} outside text");
            let ins = self.r32(pc);
            self.hist[((pc - self.text_lo) / 4) as usize] += 1;
            count += 1;
            let op = ins & 0x7f;
            let rd = ((ins >> 7) & 31) as usize;
            let f3 = (ins >> 12) & 7;
            let rs1 = ((ins >> 15) & 31) as usize;
            let rs2 = ((ins >> 20) & 31) as usize;
            let f7 = ins >> 25;
            let a = self.x[rs1];
            let b = self.x[rs2];
            let imm_i = ((ins as i32) >> 20) as u32;
            let mut next = pc.wrapping_add(4);
            let mut val: Option<u32> = None;
            match op {
                0x37 => val = Some(ins & 0xffff_f000),
                0x17 => val = Some(pc.wrapping_add(ins & 0xffff_f000)),
                0x6f => {
                    let imm = (((ins as i32) >> 31) as u32) << 20 | (ins & 0x000f_f000) | ((ins >> 9) & 0x800) | ((ins >> 20) & 0x7fe);
                    val = Some(next);
                    next = pc.wrapping_add(imm);
                }
                0x67 => { val = Some(next); next = a.wrapping_add(imm_i) & !1; }
                0x63 => {
                    let imm = (((ins as i32) >> 31) as u32) << 12 | ((ins << 4) & 0x800) | ((ins >> 20) & 0x7e0) | ((ins >> 7) & 0x1e);
                    let take = match f3 {
                        0 => a == b, 1 => a != b, 4 => (a as i32) < (b as i32), 5 => (a as i32) >= (b as i32),
                        6 => a < b, 7 => a >= b, _ => panic!("branch f3 {f3} at {pc:#x}"),
                    };
                    if take { next = pc.wrapping_add(imm); }
                }
                0x03 => {
                    let addr = a.wrapping_add(imm_i);
                    val = Some(match f3 {
                        0 => self.r8(addr) as i8 as i32 as u32, 1 => self.r16(addr) as i16 as i32 as u32, 2 => self.r32(addr),
                        4 => self.r8(addr) as u32, 5 => self.r16(addr) as u32, _ => panic!("load f3 {f3} at {pc:#x}"),
                    });
                }
                0x23 => {
                    let imm = ((((ins as i32) >> 25) as u32) << 5) | ((ins >> 7) & 31);
                    let addr = a.wrapping_add(imm);
                    match f3 { 0 => self.w8(addr, b as u8), 1 => self.w16(addr, b as u16), 2 => self.w32(addr, b), _ => panic!("store f3 {f3} at {pc:#x}") }
                }
                0x13 => {
                    let sh = imm_i & 31;
                    val = Some(match f3 {
                        0 => a.wrapping_add(imm_i), 2 => ((a as i32) < (imm_i as i32)) as u32, 3 => (a < imm_i) as u32,
                        4 => a ^ imm_i, 6 => a | imm_i, 7 => a & imm_i, 1 => a << sh,
                        5 => if f7 & 0x20 != 0 { ((a as i32) >> sh) as u32 } else { a >> sh },
                        _ => unreachable!(),
                    });
                }
                0x33 => {
                    val = Some(if f7 == 1 {
                        match f3 {
                            0 => a.wrapping_mul(b),
                            1 => (((a as i32 as i64) * (b as i32 as i64)) >> 32) as u32,
                            2 => (((a as i32 as i64) * (b as u64 as i64)) >> 32) as u32,
                            3 => (((a as u64) * (b as u64)) >> 32) as u32,
                            4 => if b == 0 { u32::MAX } else if a == 0x8000_0000 && b == u32::MAX { a } else { ((a as i32) / (b as i32)) as u32 },
                            5 => if b == 0 { u32::MAX } else { a / b },
                            6 => if b == 0 { a } else if a == 0x8000_0000 && b == u32::MAX { 0 } else { ((a as i32) % (b as i32)) as u32 },
                            7 => if b == 0 { a } else { a % b },
                            _ => unreachable!(),
                        }
                    } else {
                        match (f3, f7) {
                            (0, 0) => a.wrapping_add(b), (0, 0x20) => a.wrapping_sub(b), (1, 0) => a << (b & 31),
                            (2, 0) => ((a as i32) < (b as i32)) as u32, (3, 0) => (a < b) as u32, (4, 0) => a ^ b,
                            (5, 0) => a >> (b & 31), (5, 0x20) => ((a as i32) >> (b & 31)) as u32, (6, 0) => a | b, (7, 0) => a & b,
                            _ => panic!("op f3 {f3} f7 {f7:#x} at {pc:#x}"),
                        }
                    });
                }
                0x0f => {}
                0x73 => {
                    if ins == 0x0000_0073 { return count; }
                    panic!("system instruction {ins:#x} at {pc:#x} (ebreak = guest panic)");
                }
                _ => panic!("unknown opcode {op:#x} ins {ins:#x} at {pc:#x}"),
            }
            if let Some(v) = val { if rd != 0 { self.x[rd] = v; } }
            if self.x[2] < self.min_sp { self.min_sp = self.x[2]; }
            self.pc = next;
        }
    }
}

fn unhex(s: &str) -> Vec<u8> { (0..s.len() / 2).map(|i| u8::from_str_radix(&s[2 * i..2 * i + 2], 16).unwrap()).collect() }

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let (elf_path, tsv, hist_dir) = (&args[1], &args[2], args.get(3));
    let elf = std::fs::read(elf_path).unwrap();
    let text = std::fs::read_to_string(tsv).unwrap();
    println!("name\tcode\tticks\tclaim_bp\tscore\tend\tinstructions\tstack_bytes");
    for line in text.lines() {
        let f: Vec<&str> = line.split('\t').collect();
        let (name, level, journal, weight) = (f[0], unhex(f[1]), unhex(f[2]), f[3].parse::<u32>().unwrap());
        let mut m = load(&elf);
        m.mem[LEVEL_AT as usize..LEVEL_AT as usize + level.len()].copy_from_slice(&level);
        m.mem[JOURNAL_AT as usize..JOURNAL_AT as usize + journal.len()].copy_from_slice(&journal);
        m.x[2] = STACK_TOP;
        m.x[10] = LEVEL_AT; m.x[11] = level.len() as u32; m.x[12] = JOURNAL_AT; m.x[13] = journal.len() as u32; m.x[14] = weight;
        let count = m.run();
        println!("{name}\t{}\t{}\t{}\t{}\t{}\t{count}\t{}", m.x[10], m.x[11], m.x[12], m.x[13], m.x[14], STACK_TOP - m.min_sp);
        if let Some(dir) = hist_dir {
            let mut agg: BTreeMap<u32, u64> = BTreeMap::new();
            for (i, &c) in m.hist.iter().enumerate() { if c > 0 { agg.insert(m.text_lo + 4 * i as u32, c); } }
            let mut out = std::fs::File::create(format!("{dir}/{}.hist", name.replace('/', "__"))).unwrap();
            for (pc, c) in agg { writeln!(out, "{pc:#x}\t{c}").unwrap(); }
        }
    }
}
