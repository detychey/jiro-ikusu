//! Scratch experiment (audit): a policy that maximizes replay cost, not score. It makes as many
//! one-cell captures as it can (step into an EMPTY cell, step back), never loses a life, and
//! keeps the claim under the target so the level runs to its time limit. It plays through the
//! core's Recorder, as the repository's bots do, and prints the journals for replay.
use jiro_core::journal::{Header, Mode};
use jiro_core::level;
use jiro_core::recorder::Recorder;
use jiro_core::types::{Cell, InputMask, Pos};

fn unhex(s: &str) -> Vec<u8> {
    (0..s.len() / 2).map(|i| u8::from_str_radix(&s[2 * i..2 * i + 2], 16).unwrap()).collect()
}
fn hex(b: &[u8]) -> String {
    b.iter().map(|x| format!("{x:02x}")).collect()
}

const DIRS: [(InputMask, InputMask); 4] = [
    (InputMask::UP, InputMask::DOWN),
    (InputMask::DOWN, InputMask::UP),
    (InputMask::LEFT, InputMask::RIGHT),
    (InputMask::RIGHT, InputMask::LEFT),
];

/// Whether stepping `into` then `back` from the current state closes a one-cell cut without
/// losing a life, ending the level or reaching `claim_cap`.
fn nibble_ok(rec: &Recorder, into: InputMask, back: InputMask, claim_cap: u16) -> bool {
    let (lives, captured) = (rec.game().player.lives, rec.game().captured);
    let mut sim = rec.clone();
    if sim.step(into).unwrap().is_some() || !sim.game().player.cutting || sim.game().player.lives != lives {
        return false;
    }
    if sim.step(back).unwrap().is_some() {
        return false;
    }
    let game = sim.game();
    game.player.lives == lives && !game.player.cutting && game.captured > captured && game.claim_bp().unwrap() < claim_cap
}

fn main() {
    let text = std::fs::read_to_string(std::env::args().nth(1).unwrap()).unwrap();
    for line in text.lines() {
        let f: Vec<&str> = line.split('\t').collect();
        if !f[0].starts_with("levels/") || !f[0].ends_with("-worst") {
            continue;
        }
        let (level_bytes, old_journal) = (unhex(f[1]), unhex(f[2]));
        let lvl = level::decode(&level_bytes).unwrap();
        let mut run_nonce = [0u8; 32];
        run_nonce.copy_from_slice(&old_journal[4..36]);
        let header = Header { mode: Mode::Challenge, run_nonce, level_id: level::level_id(&level_bytes), level_index: old_journal[68] };
        let mut rec = Recorder::new(&lvl, &header).unwrap();
        let claim_cap = lvl.target_bp.saturating_sub(50);
        let mut visits = vec![0u32; 3600];
        let mut pending: Option<InputMask> = None;
        while rec.game().end.is_none() {
            let mask = if let Some(back) = pending.take() {
                back
            } else if let Some(&(into, back)) = DIRS.iter().find(|(into, back)| nibble_ok(&rec, *into, *back, claim_cap)) {
                pending = Some(back);
                into
            } else {
                // No nibble from here: move along claimed cells, or wait, without losing a life or
                // starting a cut; prefer a cell from which a nibble works, then the least visited.
                let lives = rec.game().player.lives;
                let mut best: Option<(i64, InputMask)> = None;
                for candidate in [InputMask::UP, InputMask::DOWN, InputMask::LEFT, InputMask::RIGHT, InputMask::NONE] {
                    let mut sim = rec.clone();
                    if sim.step(candidate).unwrap().is_some() || sim.game().player.lives != lives || sim.game().player.cutting {
                        continue;
                    }
                    let pos: Pos = sim.game().player.pos;
                    let moved = pos != rec.game().player.pos;
                    let can_nibble = DIRS.iter().any(|(into, back)| nibble_ok(&sim, *into, *back, claim_cap));
                    let cell = usize::from(pos.y) * 60 + usize::from(pos.x);
                    let score = i64::from(can_nibble) * 1_000_000 + i64::from(moved) * 1_000 - i64::from(visits[cell]);
                    if best.is_none_or(|(s, _)| score > s) {
                        best = Some((score, candidate));
                    }
                }
                best.map_or(InputMask::NONE, |(_, mask)| mask)
            };
            rec.step(mask).unwrap();
            let pos = rec.game().player.pos;
            visits[usize::from(pos.y) * 60 + usize::from(pos.x)] += 1;
            debug_assert!(rec.game().grid.at(pos) != Some(Cell::Empty));
        }
        let name = f[0].replace("-worst", "-nibble");
        println!("{name}\t{}\t{}\t{}\tok", f[1], hex(rec.journal()), f[3]);
    }
}
