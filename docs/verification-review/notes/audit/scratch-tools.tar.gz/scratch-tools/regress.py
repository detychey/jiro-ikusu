"""Least-squares model of RISC Zero user cycles on replay features (scratch analysis)."""
import csv, json, sys
import numpy as np
A = sys.argv[1]
cyc = json.load(open(A + "/data/cycles.json"))
rows = list(csv.DictReader(open(A + "/data/stats.tsv"), delimiter="\t"))
feat_names = ["const", "ticks", "captures", "zone_sum", "boss_edge_cells", "minion_moves", "body_checks", "journal_blocks", "events", "lives_lost", "respawns"]
X, y, names = [], [], []
for r in rows:
    n = r["name"]
    if r["status"] != "ok" or not cyc.get(n, {}).get(sys.argv[2]):
        continue
    g = lambda k: float(r[k])
    B = g("boss_size")
    X.append([1, g("ticks"), g("captures"), g("zone_sum"), g("boss_moves") * 2 * B, g("minion_moves"),
              g("moving_ticks") * B * B, (g("journal_len") + 1 + 135) // 136, g("events"), g("lives_lost"), g("respawns")])
    y.append(float(cyc[n][sys.argv[2]]))
    names.append(n)
X = np.array(X); y = np.array(y)
def fit(cols):
    Xs = X[:, cols]
    beta, res, rank, sv = np.linalg.lstsq(Xs, y, rcond=None)
    pred = Xs @ beta
    ss_res = ((y - pred) ** 2).sum(); ss_tot = ((y - y.mean()) ** 2).sum()
    return beta, pred, 1 - ss_res / ss_tot
cols = list(range(len(feat_names)))
beta, pred, r2 = fit(cols)
print("target:", sys.argv[2], " n =", len(y), " R2 = %.5f" % r2)
for c, b in zip(cols, beta):
    print("  %-16s %12.1f" % (feat_names[c], b))
err = (pred - y) / y
print("  max abs relative error: %.1f%%  median: %.1f%%" % (100 * abs(err).max(), 100 * np.median(abs(err))))
# nonnegative / reduced model
cols2 = [0, 1, 2, 3, 4, 5, 6, 7]
beta2, pred2, r22 = fit(cols2)
print("reduced model R2 = %.5f" % r22)
for c, b in zip(cols2, beta2):
    print("  %-16s %12.1f" % (feat_names[c], b))
err2 = (pred2 - y) / y
print("  max abs relative error: %.1f%%  median: %.1f%%" % (100 * abs(err2).max(), 100 * np.median(abs(err2))))
# share of each term on the gate set (levels/*) under the reduced model
gate = [i for i, n in enumerate(names) if n.startswith("levels/")]
contrib = X[:, cols2] * beta2
tot = contrib[gate].sum(axis=0)
print("gate-set share by term (reduced model), total cycles %.0f:" % y[gate].sum())
for c, t in zip(cols2, tot):
    print("  %-16s %6.1f%%" % (feat_names[c], 100 * t / pred2[gate].sum()))
for n in ["game/worst-case", "levels/10-worst", "levels/05-worst", "levels/01-synthetic", "game/open-field-capture", "game/full-journal"]:
    i = names.index(n)
    print(n, "measured %.0f predicted %.0f" % (y[i], pred2[i]), " terms:", {feat_names[c]: int(v) for c, v in zip(cols2, contrib[i])})
