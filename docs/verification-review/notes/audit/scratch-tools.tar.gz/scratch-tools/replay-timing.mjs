// Read-only measurement: how long the browser's wasm core takes to replay journals with the
// per-tick state-hash trace. Loads the already built jiro_wasm.wasm; writes nothing.
import { readFileSync, readdirSync } from "node:fs";
import { join } from "node:path";
import { performance } from "node:perf_hooks";

const REPO = process.argv[2];
const wasmPath = join(REPO, "target/wasm32-unknown-unknown/release/jiro_wasm.wasm");
const { instance } = await WebAssembly.instantiate(readFileSync(wasmPath), {});
const wasm = instance.exports;
const memory = (ptr, len) => new Uint8Array(wasm.memory.buffer, ptr, len);
const bytes = (text) => Uint8Array.from(Buffer.from(text.replace(/^0x/, ""), "hex"));
const be = (b) => b.reduce((v, x) => v * 256 + x, 0);

function replay(level, journal, weightBp) {
  memory(wasm.input_ptr(), level.length).set(level);
  memory(wasm.input_ptr() + level.length, journal.length).set(journal);
  const t0 = performance.now();
  const code = wasm.replay(level.length, journal.length, weightBp);
  const ms = performance.now() - t0;
  const at = memory(wasm.outcome_ptr(), 110);
  return { code, ms, ticks: wasm.trace_ticks(), endReason: at[101], claimBp: be(at.subarray(102, 104)), ticksUsed: be(at.subarray(104, 106)), levelScore: be(at.subarray(106, 110)) };
}

console.log(`wasm: ${readFileSync(wasmPath).length} bytes; rules_version ${wasm.rules_version()}; memory pages ${wasm.memory.buffer.byteLength / 65536}`);

const dir = join(REPO, "vectors/levels");
const rows = [];
for (const name of readdirSync(dir).filter((f) => f.endsWith(".json")).sort()) {
  const v = JSON.parse(readFileSync(join(dir, name), "utf8"));
  const level = bytes(v.level), journal = bytes(v.journal);
  // warm-up once, then take the best and median of 15
  replay(level, journal, v.weightBp);
  const runs = Array.from({ length: 15 }, () => replay(level, journal, v.weightBp));
  const sorted = runs.map((r) => r.ms).sort((a, b) => a - b);
  rows.push({ name: name.replace(".json", ""), journalBytes: journal.length, ticks: runs[0].ticks, code: runs[0].code, min: sorted[0], median: sorted[7], max: sorted[14] });
}
console.log("gate set (vectors/levels): name, journal bytes, ticks, code, ms min/median/max (replay WITH per-tick keccak state hash)");
for (const r of rows) console.log(`${r.name}\t${r.journalBytes}\t${r.ticks}\t${r.code}\t${r.min.toFixed(2)}\t${r.median.toFixed(2)}\t${r.max.toFixed(2)}`);
const med = rows.map((r) => r.median).sort((a, b) => a - b);
console.log(`per-level median over ${rows.length} vectors: min ${med[0].toFixed(2)} ms, median ${med[Math.floor(med.length / 2)].toFixed(2)} ms, max ${med[med.length - 1].toFixed(2)} ms`);
const heaviestSix = [...rows].sort((a, b) => b.median - a.median).slice(0, 6);
console.log(`six slowest vectors summed (an upper bound for a run): ${heaviestSix.reduce((s, r) => s + r.median, 0).toFixed(2)} ms: ${heaviestSix.map((r) => r.name).join(", ")}`);
console.log(`all ${rows.length} vectors summed: ${rows.reduce((s, r) => s + r.median, 0).toFixed(2)} ms, ${rows.reduce((s, r) => s + r.ticks, 0)} ticks`);

// The run settled on Arbitrum Sepolia.
const run = JSON.parse(readFileSync(join(REPO, "seasons/testnet-0/runs/run-1.json"), "utf8"));
const season = JSON.parse(readFileSync(join(REPO, "seasons/testnet-0.json"), "utf8"));
let total = 0, score = 0, ticks = 0;
for (let i = 0; i < 6; i += 1) {
  const r = replay(bytes(run.levels[i]), bytes(run.journals[i]), season.weightsBp[run.drawSlots[i]]);
  total += r.ms; score += r.levelScore; ticks += r.ticksUsed;
  console.log(`testnet-0 run 1 level ${i}: code ${r.code}, endReason ${r.endReason}, claimBp ${r.claimBp}, ticksUsed ${r.ticksUsed}, levelScore ${r.levelScore}, ${r.ms.toFixed(2)} ms`);
}
console.log(`testnet-0 run 1: score ${score}, ticks ${ticks}, replayed in ${total.toFixed(2)} ms; journals ${run.journals.reduce((s, j) => s + (j.length - 2) / 2, 0)} bytes`);
