//! Audit probe, outside the repository: restores a `Game` from (level, run nonce, level index,
//! state-hash v1 preimage) with public items of jiro-core only, and checks that one `Game::step`
//! from the restored state reproduces the next recorded preimage, for every tick of every
//! accepted game vector given on the command line. It also checks what the last preimage and the
//! level-start state determine. Read-only on the repository.

use std::num::NonZeroU16;

use jiro_core::boss::Boss;
use jiro_core::game::{EndReason, Game};
use jiro_core::hash::{PREIMAGE_LEN, preimage, state_hash};
use jiro_core::journal::{self, Event};
use jiro_core::level::{self, Level};
use jiro_core::minion::{Minion, State};
use jiro_core::player::Player;
use jiro_core::replay::replay_observed;
use jiro_core::types::{Cell, CellIndex, Dir, InputMask, Pos};

const TAIL: usize = 904;

fn restore(level: &Level, run_nonce: &[u8; 32], level_index: u8, pre: &[u8; PREIMAGE_LEN]) -> Game {
    // Game::new gives what the preimage leaves out: the deflection key (level seed), target_bp,
    // time_limit, the minions' respawn delay, and the private capture stack (scratch).
    let mut game = Game::new(level, run_nonce, level_index).expect("a valid level");
    assert_eq!(pre[0], 1, "state hash version");
    game.ticks_used = u16::from_be_bytes([pre[1], pre[2]]) + 1;
    game.mask = InputMask::new(pre[3]).expect("a mask without bit 7");
    for cell in CellIndex::all() {
        let i = cell.get();
        let value = (pre[4 + i / 4] >> (6 - 2 * (i % 4))) & 0b11;
        game.grid.set(
            cell,
            match value {
                0 => Cell::Empty,
                1 => Cell::Claimed,
                2 => Cell::Trail,
                _ => Cell::BossZone,
            },
        );
    }
    let p = &pre[TAIL..];
    game.player = Player {
        pos: Pos { x: p[0], y: p[1] },
        cutting: p[2] == 1,
        cut_start: Pos { x: p[3], y: p[4] },
        lives: p[5],
        shield: p[6],
        invulnerable: p[7],
        direction: match p[8] {
            0 => None,
            1 => Some(Dir::Up),
            2 => Some(Dir::Down),
            3 => Some(Dir::Left),
            4 => Some(Dir::Right),
            other => panic!("direction {other}"),
        },
        press_tick: u16::from_be_bytes([p[9], p[10]]),
    };
    game.boss = Boss {
        pos: Pos { x: p[11], y: p[12] },
        size: p[13],
        vx: p[14] as i8,
        vy: p[15] as i8,
        period: p[16],
        deflection_key: game.boss.deflection_key,
    };
    for slot in 0..3 {
        let m = &p[17 + 7 * slot..24 + 7 * slot];
        // The spawn cell is a level constant, outside the preimage.
        let spawn = level.minion_spawns[slot];
        game.minions.slots[slot] = match m[0] {
            0 => None,
            1 => Some(Minion {
                spawn,
                state: State::Live {
                    pos: Pos { x: m[1], y: m[2] },
                    heading: match m[3] {
                        0 => Dir::Up,
                        1 => Dir::Right,
                        2 => Dir::Down,
                        3 => Dir::Left,
                        other => panic!("heading {other}"),
                    },
                },
            }),
            2 => Some(Minion {
                spawn,
                state: State::Destroyed {
                    countdown: u16::from_be_bytes([m[5], m[6]]),
                },
            }),
            other => panic!("presence {other}"),
        };
    }
    game.captured = u16::from_be_bytes([p[38], p[39]]);
    game.claimable = NonZeroU16::new(u16::from_be_bytes([p[40], p[41]])).expect("claimable");
    game.events_applied = u16::from_be_bytes([p[42], p[43]]);
    game.end = None;
    game
}

/// The end reason from the last preimage and the level's constants alone.
fn end_reason_of(level: &Level, last: &[u8; PREIMAGE_LEN]) -> Option<EndReason> {
    let p = &last[TAIL..];
    let tick = u16::from_be_bytes([last[1], last[2]]);
    let captured = u32::from(u16::from_be_bytes([p[38], p[39]]));
    let claimable = u32::from(u16::from_be_bytes([p[40], p[41]]));
    let claim_bp = captured * 10_000 / claimable;
    if last[3] & 0x40 != 0 {
        Some(EndReason::Committed)
    } else if claim_bp >= u32::from(level.target_bp) {
        Some(EndReason::Cleared)
    } else if p[5] == 0 {
        Some(EndReason::OutOfLives)
    } else if tick + 1 == level.time_limit {
        Some(EndReason::TimeLimit)
    } else {
        None
    }
}

fn field<'a>(text: &'a str, key: &str) -> Option<&'a str> {
    let at = text.find(&format!("\"{key}\":"))? + key.len() + 3;
    let rest = text[at..].trim_start();
    match rest.strip_prefix('"') {
        Some(quoted) => quoted.split('"').next(),
        None => rest.split([',', '\n', '}']).next().map(str::trim),
    }
}

fn hex(text: &str) -> Vec<u8> {
    let digits = text.strip_prefix("0x").expect("0x");
    (0..digits.len() / 2)
        .map(|i| u8::from_str_radix(&digits[2 * i..2 * i + 2], 16).expect("hex"))
        .collect()
}

struct Stats {
    vectors: u32,
    skipped: u32,
    steps: u64,
    setup_steps: u32,
    max_changed_bytes: usize,
    changed_bytes: u64,
}

fn check(path: &str, stats: &mut Stats) -> Result<(), String> {
    let text = std::fs::read_to_string(path).map_err(|e| format!("{path}: {e}"))?;
    if text.contains("\"error\":") {
        stats.skipped += 1;
        return Ok(());
    }
    let level_bytes = hex(field(&text, "level").ok_or("no level")?);
    let journal_bytes = hex(field(&text, "journal").ok_or("no journal")?);
    let weight: u16 = field(&text, "weightBp").ok_or("no weightBp")?.parse().map_err(|_| "weightBp")?;
    let journal = journal::decode(&journal_bytes).map_err(|e| format!("journal {e:?}"))?;
    let level = level::decode(&level_bytes).map_err(|e| format!("level {e:?}"))?;
    let (nonce, index) = (journal.header.run_nonce, journal.header.level_index);
    let events: Vec<Event> = journal.events().collect();

    let mut pres: Vec<[u8; PREIMAGE_LEN]> = Vec::new();
    let mut hashes: Vec<[u8; 32]> = Vec::new();
    let outcome = replay_observed(&level_bytes, &journal_bytes, weight, |game| {
        pres.push(preimage(game));
        hashes.push(state_hash(game));
    })
    .map_err(|e| format!("replay {e:?}"))?;

    // The mask of the next tick from a state and the journal alone.
    let next_mask = |game: &Game| match events.get(usize::from(game.events_applied)) {
        Some(event) if event.tick == game.ticks_used => event.mask,
        _ => game.mask,
    };

    // Level start: Game::new, then one step, gives the first recorded state.
    let mut start = Game::new(&level, &nonce, index).map_err(|e| format!("new {e:?}"))?;
    let start_pre = preimage(&start);
    if start_pre[1..3] != pres[0][1..3] {
        return Err("the level-start preimage's tick field differs from tick 0's".into());
    }
    let mask = next_mask(&start);
    let end = start.step(mask).map_err(|e| format!("step {e:?}"))?;
    if preimage(&start) != pres[0] {
        return Err("Game::new + step differs from the first recorded preimage".into());
    }
    stats.setup_steps += 1;
    if pres.len() == 1 && end != Some(outcome.end_reason) {
        return Err("end reason at tick 0".into());
    }

    for t in 0..pres.len() - 1 {
        let mut game = restore(&level, &nonce, index, &pres[t]);
        if preimage(&game) != pres[t] {
            return Err(format!("tick {t}: the restored game does not re-encode to its preimage"));
        }
        let mask = next_mask(&game);
        let end = game.step(mask).map_err(|e| format!("tick {t}: step {e:?}"))?;
        let after = preimage(&game);
        if after != pres[t + 1] || state_hash(&game) != hashes[t + 1] {
            return Err(format!("tick {}: one step from the restored state differs", t + 1));
        }
        let last = t + 1 == pres.len() - 1;
        if last != end.is_some() {
            return Err(format!("tick {}: end {end:?}, last {last}", t + 1));
        }
        let changed = after.iter().zip(&pres[t]).filter(|(a, b)| a != b).count();
        stats.max_changed_bytes = stats.max_changed_bytes.max(changed);
        stats.changed_bytes += changed as u64;
        stats.steps += 1;
    }

    let last = pres.last().ok_or("no tick")?;
    let derived = end_reason_of(&level, last).ok_or("no end reason derivable from the last preimage")?;
    if derived != outcome.end_reason {
        return Err(format!("end reason derived {derived:?}, outcome {:?}", outcome.end_reason));
    }
    // No earlier state looks final by the same rule.
    for (t, pre) in pres.iter().enumerate().take(pres.len() - 1) {
        if end_reason_of(&level, pre).is_some() {
            return Err(format!("tick {t}: a non-final preimage looks final"));
        }
    }
    let p = &last[TAIL..];
    let captured = u32::from(u16::from_be_bytes([p[38], p[39]]));
    let claimable = u32::from(u16::from_be_bytes([p[40], p[41]]));
    let ticks = u16::from_be_bytes([last[1], last[2]]) + 1;
    let applied = usize::from(u16::from_be_bytes([p[42], p[43]]));
    if (captured * 10_000 / claimable) as u16 != outcome.claim_bp || ticks != outcome.ticks_used || applied != events.len() {
        return Err("claim, ticks or event count not derivable from the last preimage".into());
    }
    stats.vectors += 1;
    Ok(())
}

fn main() {
    let mut stats = Stats { vectors: 0, skipped: 0, steps: 0, setup_steps: 0, max_changed_bytes: 0, changed_bytes: 0 };
    let mut failures = 0;
    for path in std::env::args().skip(1) {
        if let Err(error) = check(&path, &mut stats) {
            failures += 1;
            println!("FAIL {path}: {error}");
        }
    }
    println!(
        "restore-check: {} accepted vectors ({} rejected ones skipped), {} single steps from restored preimages, {} level starts, {} failures; preimage bytes changed per tick: mean {:.1}, max {}",
        stats.vectors,
        stats.skipped,
        stats.steps,
        stats.setup_steps,
        failures,
        stats.changed_bytes as f64 / stats.steps.max(1) as f64,
        stats.max_changed_bytes,
    );
    if failures > 0 {
        std::process::exit(1);
    }
}
