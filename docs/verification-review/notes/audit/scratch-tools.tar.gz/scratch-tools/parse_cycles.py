"""Parse the RISC Zero and SP1 executor tables and the Stylus gas table of docs/VERIFICATION.md."""
import re, json, sys
doc = open("/home/user/jiro-ikusu/docs/VERIFICATION.md").read().split("\n")
def num(s):
    s = s.strip().replace(",", "")
    return int(s) if s.isdigit() else None
out = {}
section = None
sub = None
for i, line in enumerate(doc):
    if line.startswith("### SP1 and RISC Zero"): section = None
    elif line.startswith("### SP1"): section = "sp1"
    elif line.startswith("### RISC Zero"): section = "r0"
    elif line.startswith("### M1.12"): section = None
    elif line.startswith("## Stylus gas"): section = "stylus"
    elif line.startswith("## zkVM trials"): section = None
    if line.startswith("##### `vectors/game/`"): sub = "game"
    elif line.startswith("##### `vectors/levels/`"): sub = "levels"
    elif line.startswith("#### ") or line.startswith("### "): sub = None if not line.startswith("### Table") else "stylus"
    cells = [c.strip() for c in line.strip().strip("|").split("|")]
    if section == "stylus" and line.startswith("| ") and "/" in cells[0] and cells[0].split("/")[0] in ("game", "levels"):
        name = cells[0]
        out.setdefault(name, {})["stylus_gas"] = num(cells[3])
    elif section in ("sp1", "r0") and sub in ("game", "levels") and line.startswith("| `"):
        name = sub + "/" + cells[0].strip("`")
        d = out.setdefault(name, {})
        if section == "sp1":
            d["sp1_cycles"] = num(cells[2]); d["sp1_pgu"] = num(cells[3]); d["sp1_trace"] = num(cells[4])
        else:
            d["r0_user"] = num(cells[2]); d["r0_proving"] = num(cells[3]); d["r0_segments"] = num(cells[4]); d["r0_trace"] = num(cells[5])
json.dump(out, open(sys.argv[1], "w"), indent=1)
print(len(out), "vectors;", sum(1 for v in out.values() if v.get("r0_user")), "with r0 user cycles;", sum(1 for v in out.values() if v.get("stylus_gas")), "with stylus gas")
