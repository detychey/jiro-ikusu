// Times jiro-wasm's `replay` (which also records the state hash of every tick) under Node on
// game vectors, to set against the zk prover's time for the same replays.
// Usage: node time-replay.mjs <repo root> <jiro_wasm.wasm> <vector file>...
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { performance } from "node:perf_hooks";

const [repoRoot, wasmPath, ...files] = process.argv.slice(2);
const { loadWasm, bytes } = await import(join(repoRoot, "web/test/wasm.mjs"));
const { wasm, input, outcome } = await loadWasm(wasmPath);

const REPEATS = 20;
let runTotal = 0;
for (const file of files) {
  const vector = JSON.parse(readFileSync(join(repoRoot, file), "utf8"));
  const level = bytes(vector.level);
  const journal = bytes(vector.journal);
  const lengths = input(level, journal);
  const first = performance.now();
  const code = wasm.replay(...lengths, vector.weightBp);
  const firstMs = performance.now() - first;
  if (code !== 0) throw new Error(`${file}: replay returns ${code}`);
  const replayed = outcome();
  for (const [field, value] of Object.entries(vector.outcome)) {
    if (replayed[field] !== value) throw new Error(`${file}: ${field} ${replayed[field]}, the vector records ${value}`);
  }
  const started = performance.now();
  for (let i = 0; i < REPEATS; i += 1) wasm.replay(...input(level, journal), vector.weightBp);
  const meanMs = (performance.now() - started) / REPEATS;
  runTotal += meanMs;
  console.log(
    `${file}: ticks ${replayed.ticksUsed}, journal ${journal.length} B, first call ${firstMs.toFixed(1)} ms, mean of ${REPEATS} ${meanMs.toFixed(2)} ms, trace ticks ${wasm.trace_ticks()}`,
  );
}
console.log(`sum of the means over ${files.length} levels: ${runTotal.toFixed(1)} ms`);
