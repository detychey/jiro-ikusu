"""Attribute per-pc instruction counts of the scratch RV32IM run to core functions (inline chains)."""
import json, subprocess, sys, glob, os, collections
A, elf, histdir = sys.argv[1], sys.argv[2], sys.argv[3]
names = sys.argv[4:]
hists = {}
pcs = set()
for n in names:
    h = {}
    for line in open("%s/%s.hist" % (histdir, n.replace("/", "__"))):
        pc, c = line.split("\t")
        h[int(pc, 16)] = int(c)
    hists[n] = h
    pcs |= set(h)
pcs = sorted(pcs)
out = subprocess.run(["llvm-symbolizer", "--obj=" + elf, "--inlines", "--demangle", "--output-style=JSON"],
                     input="\n".join(hex(p) for p in pcs), capture_output=True, text=True).stdout
chains = {}
for line in out.splitlines():
    j = json.loads(line)
    frames = [(s["FunctionName"], os.path.basename(s["FileName"]), s["Line"]) for s in j["Symbol"]]
    chains[int(j["Address"], 16)] = frames

syms = []
for line in subprocess.run(["llvm-nm", "-n", "-S", "--defined-only", "--demangle", elf], capture_output=True, text=True).stdout.splitlines():
    p = line.split(None, 3)
    if len(p) == 4 and p[2] in "tT" and not p[3].startswith(".L"):
        syms.append((int(p[0], 16), int(p[1], 16), p[3]))
def symbol(pc):
    for a, sz, n in syms:
        if a <= pc < a + sz:
            return n
    return "?"

def bucket(frames, pc=0):
    sym = symbol(pc)
    if "keccak" in sym or "journal_hash" in sym:
        return "keccak256 (level id, journal hash, seed, draw)"
    if "is_rail" in sym:
        return "is_rail (minion steps, player rail moves)"
    if "minion::orient" in sym:
        return "minions (right-hand step, orient, respawn)"
    if "seed::draw" in sym:
        return "seed and draw arithmetic"
    if "mem" in sym:
        return "memcpy/memset"
    fn = [f[0] for f in frames]
    files = [f[1] for f in frames]
    joined = " | ".join(fn)
    def has(s): return any(s in x for x in fn)
    in_setup = has("validate") or has("Game::new") or any(f[0] == "new" and f[1] == "game.rs" for f in frames) or has("level_start")
    if has("keccakf") or any(f == "keccak.rs" for f in files) or has("tiny_keccak") or "keccak" in joined.lower():
        return "keccak256 (level id, journal hash, seed, draw)"
    if has("mark_boss_zone"):
        if has("validate"): return "flood fill in level validation (setup)"
        return "flood fill in capture"
    if any(f[0].startswith("capture") and f[1] == "capture.rs" for f in frames) or "capture.rs" in files:
        return "capture: one pass over 3,600 cells"
    if has("validate") or "level.rs" in files and (has("level_start") or has("spawn_covers") or has("obstacle_bits")):
        return "level validation, other (grid build, counts, spawn area)"
    if "level.rs" in files:
        return "level decode and range checks"
    if "journal.rs" in files:
        return "journal decode and event checks"
    if "minion.rs" in files or has("orient") or has("right_hand_step"):
        return "minions (right-hand step, orient, respawn)"
    if has("is_rail"):
        return "is_rail (minion steps, player rail moves)"
    if "boss.rs" in files:
        return "boss (edge tests, body iteration)"
    if "player.rs" in files:
        return "player step"
    if "hits.rs" in files:
        return "hits"
    if "seed.rs" in files:
        return "seed and draw arithmetic"
    if any(x in ("memcpy", "memset", "memcmp") or "compiler_builtins" in x for x in fn):
        return "memcpy/memset"
    if "grid.rs" in files:
        return "grid, other (count, replace, level_start)"
    if "game.rs" in files or "replay.rs" in files:
        return "replay loop and tick dispatch"
    return "other: " + (fn[0] if fn else "?")

agg = {n: collections.Counter() for n in names}
for n in names:
    for pc, c in hists[n].items():
        agg[n][bucket(chains[pc], pc)] += c
buckets = sorted({b for n in names for b in agg[n]}, key=lambda b: -sum(agg[n][b] for n in names))
tot_all = sum(sum(agg[n].values()) for n in names)
if len(names) <= 8:
    print("%-58s" % "bucket" + "".join("%22s" % n.split("/")[-1][:21] for n in names))
    for b in buckets:
        print("%-58s" % b[:57] + "".join("%14d %6.1f%%" % (agg[n][b], 100 * agg[n][b] / sum(agg[n].values())) for n in names))
    print("%-58s" % "total" + "".join("%14d %7s" % (sum(agg[n].values()), "") for n in names))
else:
    print("aggregate over %d vectors, %d instructions" % (len(names), tot_all))
    for b in buckets:
        s = sum(agg[n][b] for n in names)
        print("  %-58s %14d %6.1f%%" % (b[:57], s, 100 * s / tot_all))
json.dump({n: dict(agg[n]) for n in names}, open(A + "/data/profile-%s.json" % os.path.basename(histdir), "w"), indent=1)
