// Arithmetic on the repository's recorded figures; nothing here is measured.
const hoursLow = 9, hoursHigh = 17;           // per six-level run on 4 CPUs (docs/DEPLOYMENT.md §6, docs/VERIFICATION.md Proving)
const boundless = 0.0000184;                  // ETH per Groth16 proof, p50 (docs/VERIFICATION.md Prover network price)
const settleGasEth = 0.0000161;               // 804,194 gas at 0.020036 gwei (docs/VERIFICATION.md Costs side by side)
const fee = 0.00005, ethUsd = 2295.05;        // README §8; docs/VERIFICATION.md:763
const marketPerDay = 1376 / 7;                // fulfilled Boundless requests in the week read
console.log(`run fee: ${fee} ETH = $${(fee * ethUsd).toFixed(4)}`);
console.log(`runs one 4-CPU machine proves in a 24 h grace: ${Math.floor(24 / hoursHigh)}-${Math.floor(24 / hoursLow)}; in 48 h: ${Math.floor(48 / hoursHigh)}-${Math.floor(48 / hoursLow)}; in 30 days (max grace): ${Math.floor(720 / hoursHigh)}-${Math.floor(720 / hoursLow)}; over 14 d + 48 h: ${Math.floor(384 / hoursHigh)}-${Math.floor(384 / hoursLow)}`);
for (const n of [20, 100, 1000, 10000]) {
  const lo = n * hoursLow, hi = n * hoursHigh;
  const m = (h, window) => Math.ceil(h / window);
  console.log(`N=${n}: ${lo}-${hi} machine-hours (${(lo / 24).toFixed(1)}-${(hi / 24).toFixed(1)} machine-days, ${(lo * 4)}-${(hi * 4)} vCPU-hours); machines for a 24 h grace ${m(lo, 24)}-${m(hi, 24)}, 48 h ${m(lo, 48)}-${m(hi, 48)}, 30 d ${m(lo, 720)}-${m(hi, 720)}, season+48h (384 h) ${m(lo, 384)}-${m(hi, 384)}`);
  console.log(`   Boundless: ${(n * boundless).toFixed(5)} ETH ($${(n * boundless * ethUsd).toFixed(2)}); settle gas ${(n * settleGasEth).toFixed(5)} ETH; total ${(n * (boundless + settleGasEth)).toFixed(5)} ETH ($${(n * (boundless + settleGasEth) * ethUsd).toFixed(2)}); proofs per day in a 48 h grace ${(n / 2).toFixed(0)} = ${(n / 2 / marketPerDay).toFixed(1)}x the market's ${marketPerDay.toFixed(0)}/day`);
}
const cost = boundless + settleGasEth;
console.log(`verified run: ${cost.toFixed(7)} ETH = ${(100 * cost / fee).toFixed(0)}% of the fee`);
for (const rakeBp of [1000, 2000]) console.log(`rake ${rakeBp} bp: ${(fee * rakeBp / 10000)} ETH per run; paid runs per verified wallet to break even ${(cost / (fee * rakeBp / 10000)).toFixed(2)}`);
console.log(`native proving rate: ${(2 ** 20 / 400).toFixed(0)} cycles/s on 4 CPUs (2^20 cycles per ~400 s); real runs 69-85M cycles -> ${(69e6 / (2 ** 20 / 400) / 3600).toFixed(1)}-${(85e6 / (2 ** 20 / 400) / 3600).toFixed(1)} h of segment proving; heaviest 136.4M -> ${(136.4e6 / (2 ** 20 / 400) / 3600).toFixed(1)} h`);
console.log(`for a 5-minute proof of 69-137M cycles: ${(69e6 / 300).toFixed(0)}-${(137e6 / 300).toFixed(0)} cycles/s, ${(69e6 / 300 / (2 ** 20 / 400)).toFixed(0)}-${(137e6 / 300 / (2 ** 20 / 400)).toFixed(0)}x the measured 4-CPU rate`);
console.log(`replay vs proof: testnet-0 run 1 proved in 4515.3 s, replayed in 3.4 ms -> ${(4515.3 / 0.0034).toExponential(2)}x; heaviest run ~16.5 h vs ~0.19 s -> ${(16.5 * 3600 / 0.19).toExponential(2)}x`);
console.log(`stylus: 33.3-50.9M gas per run at 0.020036 gwei = ${(33.3e6 * 0.020036e-9).toFixed(5)}-${(50.9e6 * 0.020036e-9).toFixed(5)} ETH = ${(33.3e6 * 0.020036e-9 / fee).toFixed(1)}-${(50.9e6 * 0.020036e-9 / fee).toFixed(1)}x the fee`);
console.log(`season page log scan: blocks per day at 0.25 s ${86400 / 0.25}; 14 d ${14 * 86400 / 0.25} blocks = ${Math.ceil(14 * 86400 / 0.25 / 10000)} chunks per event; 16 d ${Math.ceil(16 * 86400 / 0.25 / 10000)}; x3 events = ${3 * Math.ceil(16 * 86400 / 0.25 / 10000)} calls; 90 d after start: ${3 * Math.ceil(90 * 86400 / 0.25 / 10000)} calls`);
console.log(`observed Sepolia block rate 2026-11-09: ${(327569544 - 327552759)} blocks in ${(13 * 3600 + 32 * 60 + 9) - (12 * 3600 + 14 * 60 + 45)} s = ${((327569544 - 327552759) / ((13 * 3600 + 32 * 60 + 9) - (12 * 3600 + 14 * 60 + 45))).toFixed(2)} blocks/s`);
console.log(`calldata share of a verified run's gas: 353,908 / 804,194 = ${(100 * 353908 / 804194).toFixed(0)}%`);
