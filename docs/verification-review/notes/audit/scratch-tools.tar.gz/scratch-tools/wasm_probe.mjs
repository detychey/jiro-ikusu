// Read-only probe of the prebuilt jiro-wasm module: exports, replay time with the per-tick trace,
// preimage restoration facts. Usage: node wasm_probe.mjs <repo root>
import { readFileSync, readdirSync } from "node:fs";
import { join } from "node:path";
import { createHash } from "node:crypto";

const root = process.argv[2];
const wasmPath = join(root, "target/wasm32-unknown-unknown/release/jiro_wasm.wasm");
const bytesOf = (text) => Uint8Array.from(Buffer.from(text.replace(/^0x/, ""), "hex"));
const hex = (b) => "0x" + Buffer.from(b).toString("hex");
const wasmBytes = readFileSync(wasmPath);
console.log("wasm bytes:", wasmBytes.length, "sha256", createHash("sha256").update(wasmBytes).digest("hex").slice(0, 16));
const { instance } = await WebAssembly.instantiate(wasmBytes, {});
const w = instance.exports;
console.log("exports:", Object.keys(w).sort().join(" "));
console.log("memory pages:", w.memory.buffer.byteLength / 65536, "rules_version:", w.rules_version());
const mem = (ptr, len) => new Uint8Array(w.memory.buffer, ptr, len);
function input(...parts) {
  let at = 0;
  for (const p of parts) { mem(w.input_ptr() + at, p.length).set(p); at += p.length; }
  return parts.map((p) => p.length);
}
function timeReplay(file) {
  const v = JSON.parse(readFileSync(join(root, file), "utf8"));
  const level = bytesOf(v.level), journal = bytesOf(v.journal);
  const lens = input(level, journal);
  // warm up, then time 20 replays with the per-tick trace
  w.replay(...lens, v.weightBp);
  const n = 20;
  const t0 = performance.now();
  let code = 0;
  for (let i = 0; i < n; i++) { input(level, journal); code = w.replay(...lens, v.weightBp); }
  const ms = (performance.now() - t0) / n;
  const ticks = w.trace_ticks();
  // time fetching the preimage of the last tick (a second full replay)
  const t1 = performance.now();
  input(level, journal);
  const pcode = w.replay_preimage(...lens, v.weightBp, ticks - 1);
  const pms = performance.now() - t1;
  const pre = mem(w.preimage_ptr(), w.preimage_len()).slice();
  return { file, code, ticks, journalBytes: journal.length, msPerReplayWithTrace: +ms.toFixed(3), preimageCode: pcode, preimageMs: +pms.toFixed(3), preimageLen: pre.length, preTick: (pre[1] << 8) | pre[2], outcomeTicks: v.outcome?.ticksUsed };
}
for (const f of ["vectors/levels/10-worst.json", "vectors/game/worst-case.json", "vectors/game/full-journal.json", "vectors/game/open-field-empty.json", "vectors/levels/16-worst.json"]) {
  console.log(JSON.stringify(timeReplay(f)));
}
// The whole gate set: total time for 32 replays with traces
const dir = join(root, "vectors/levels");
const files = readdirSync(dir).filter((n) => n.endsWith(".json")).sort();
let total = 0, ticksTotal = 0;
const t0 = performance.now();
for (const n of files) {
  const v = JSON.parse(readFileSync(join(dir, n), "utf8"));
  const lens = input(bytesOf(v.level), bytesOf(v.journal));
  const code = w.replay(...lens, v.weightBp);
  if (code !== 0) throw new Error(n + " code " + code);
  ticksTotal += w.trace_ticks();
}
total = performance.now() - t0;
console.log(`gate set: ${files.length} levels, ${ticksTotal} ticks, ${total.toFixed(1)} ms in all (JSON parsing included), ${(total / files.length).toFixed(2)} ms per level`);
