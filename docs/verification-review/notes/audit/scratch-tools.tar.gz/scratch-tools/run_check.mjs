// Read-only: replays a run file's six levels in the prebuilt wasm core at its season's weights and
// compares each (weightBp, Outcome) with the committed proof's public values.
// Usage: node run_check.mjs <repo root> <run file> <season file> <proof json> [proof key]
import { readFileSync } from "node:fs";
import { join } from "node:path";
const [root, runPath, seasonPath, proofPath, key] = process.argv.slice(2);
const bytesOf = (t) => Uint8Array.from(Buffer.from(t.replace(/^0x/, ""), "hex"));
const hex = (b) => "0x" + Buffer.from(b).toString("hex");
const { instance } = await WebAssembly.instantiate(readFileSync(join(root, "target/wasm32-unknown-unknown/release/jiro_wasm.wasm")), {});
const w = instance.exports;
const mem = (p, l) => new Uint8Array(w.memory.buffer, p, l);
const input = (...parts) => { let at = 0; for (const p of parts) { mem(w.input_ptr() + at, p.length).set(p); at += p.length; } return parts.map((p) => p.length); };
const be = (b) => b.reduce((v, x) => v * 256 + x, 0);
const run = JSON.parse(readFileSync(join(root, runPath), "utf8"));
const season = JSON.parse(readFileSync(join(root, seasonPath), "utf8"));
let proof = JSON.parse(readFileSync(join(root, proofPath), "utf8"));
if (key) proof = proof[key];
const pv = bytesOf(proof.publicValues);
let ok = true, score = 0, ticks = 0, clears = 0, journalBytes = 0, traceBytes = 0;
for (let i = 0; i < 6; i++) {
  const level = bytesOf(run.levels[i]), journal = bytesOf(run.journals[i]);
  journalBytes += journal.length;
  const weight = season.weightsBp[run.drawSlots[i]];
  const code = w.replay(...input(level, journal), weight);
  if (code !== 0) { console.log("level", i, "replay code", code); ok = false; continue; }
  const o = mem(w.outcome_ptr(), 110).slice();
  traceBytes += w.trace_ticks() * 32;
  const fields = [o.subarray(0, 32), o.subarray(32, 64), o.subarray(64, 96), o.subarray(96, 97), o.subarray(97, 98), o.subarray(98, 99), o.subarray(99, 101), o.subarray(101, 102), o.subarray(102, 104), o.subarray(104, 106), o.subarray(106, 110)];
  const words = [Uint8Array.from([weight >> 8, weight & 255]), ...fields].map((f) => { const word = new Uint8Array(32); if (f.length === 32) word.set(f); else word.set(f, 32 - f.length); return word; });
  const expected = Buffer.concat(words);
  const got = Buffer.from(pv.subarray(i * 384, (i + 1) * 384));
  const same = expected.equals(got);
  ok &&= same;
  const eventCount = be(journal.subarray(69, 71));
  const lastEvent = eventCount ? { tick: be(journal.subarray(71 + 3 * (eventCount - 1), 73 + 3 * (eventCount - 1))), mask: journal[73 + 3 * (eventCount - 1)] } : null;
  console.log(`level ${i}: slot ${run.drawSlots[i]} weight ${weight} endReason ${o[101]} claimBp ${be(o.subarray(102, 104))} ticksUsed ${be(o.subarray(104, 106))} score ${be(o.subarray(106, 110))} events ${eventCount} lastEvent ${JSON.stringify(lastEvent)} publicValuesMatch ${same}`);
  score += be(o.subarray(106, 110)); ticks += be(o.subarray(104, 106)); clears += o[101] === 2 ? 1 : 0;
}
console.log(`run ${run.runId}: score ${score}, ticks ${ticks}, clears ${clears}, journals ${journalBytes} bytes, trace ${traceBytes} bytes; public values match the wasm replay: ${ok}`);
