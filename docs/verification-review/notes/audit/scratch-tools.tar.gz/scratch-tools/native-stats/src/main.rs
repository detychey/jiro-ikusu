//! Scratch analysis: replays each vector natively and counts the events that drive replay cost.
use jiro_core::level;
use jiro_core::minion::State;
use jiro_core::replay::replay_observed;
use jiro_core::types::Cell;

fn unhex(s: &str) -> Vec<u8> {
    (0..s.len() / 2)
        .map(|i| u8::from_str_radix(&s[2 * i..2 * i + 2], 16).unwrap())
        .collect()
}

fn main() {
    let path = std::env::args().nth(1).expect("tsv path");
    let text = std::fs::read_to_string(path).unwrap();
    println!(
        "name\tstatus\tticks\tevents\tjournal_len\tboss_size\tboss_period\tminion_count\tminion_period\tclaimable\tcaptures\tzone_sum\tzone_max\tcaptured\tlives_lost\tboss_moves\tminion_moves\trespawns\tmoving_ticks\tcutting_ticks\tend\tclaim_bp"
    );
    for line in text.lines() {
        let f: Vec<&str> = line.split('\t').collect();
        let (name, level_bytes, journal, weight) =
            (f[0], unhex(f[1]), unhex(f[2]), f[3].parse::<u16>().unwrap());
        let events = if journal.len() >= 71 {
            u16::from_be_bytes([journal[69], journal[70]])
        } else {
            0
        };
        let lvl = level::decode(&level_bytes).ok();
        let mut captures = 0u32;
        let mut zone_sum = 0u64;
        let mut zone_max = 0u32;
        let mut lives_lost = 0u32;
        let mut boss_moves = 0u32;
        let mut minion_moves = 0u32;
        let mut respawns = 0u32;
        let mut moving = 0u32;
        let mut cutting = 0u32;
        let mut prev_captured = 0u16;
        let mut prev_lives: Option<u8> = None;
        let mut prev_live = [false; 3];
        let mut first = true;
        let mut claimable = 0u16;
        let result = replay_observed(&level_bytes, &journal, weight, |game| {
            let tick = game.ticks_used - 1;
            if first {
                first = false;
                claimable = game.claimable.get();
                // before tick 0 every level minion is live
                for (slot, live) in game.minions.slots.iter().zip(prev_live.iter_mut()) {
                    *live = slot.is_some();
                }
            }
            if game.captured > prev_captured {
                captures += 1;
                let zone = u32::from(game.grid.count(Cell::Empty));
                zone_sum += u64::from(zone);
                zone_max = zone_max.max(zone);
                prev_captured = game.captured;
            }
            if let Some(lives) = prev_lives {
                if game.player.lives < lives {
                    lives_lost += 1;
                }
            } else if let Some(l) = lvl.as_ref() {
                if game.player.lives < l.lives {
                    lives_lost += 1;
                }
            }
            prev_lives = Some(game.player.lives);
            if tick % u16::from(game.boss.period) == 0 {
                boss_moves += 1;
            }
            let period = u16::from(game.minions.period);
            for (slot, was_live) in game.minions.slots.iter().zip(prev_live.iter_mut()) {
                let Some(minion) = slot else { continue };
                let live = matches!(minion.state, State::Live { .. });
                if *was_live && period > 0 && tick % period == 0 {
                    minion_moves += 1;
                }
                if live && !*was_live {
                    respawns += 1;
                }
                *was_live = live;
            }
            if game.player.direction.is_some() {
                moving += 1;
            }
            if game.player.cutting {
                cutting += 1;
            }
        });
        let (status, ticks, end, claim) = match result {
            Ok(o) => ("ok".to_string(), o.ticks_used, o.end_reason as u8, o.claim_bp),
            Err(e) => (format!("err{}", e.code()), 0, 0, 0),
        };
        let l = lvl.as_ref();
        println!(
            "{name}\t{status}\t{ticks}\t{events}\t{}\t{}\t{}\t{}\t{}\t{claimable}\t{captures}\t{zone_sum}\t{zone_max}\t{prev_captured}\t{lives_lost}\t{boss_moves}\t{minion_moves}\t{respawns}\t{moving}\t{cutting}\t{end}\t{claim}",
            journal.len(),
            l.map_or(0, |l| l.boss_size),
            l.map_or(0, |l| l.boss_period),
            l.map_or(0, |l| l.minion_count),
            l.map_or(0, |l| l.minion_period),
        );
    }
}
