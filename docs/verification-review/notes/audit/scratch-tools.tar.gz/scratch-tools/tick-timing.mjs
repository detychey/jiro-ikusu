// Read-only measurement: the cost of single ticks in the browser's wasm core, to size a
// one-tick dispute step. Plays each gate-set journal tick by tick through load_level/start/tick
// (no state hash), five passes, and keeps each tick's minimum time.
import { readFileSync, readdirSync } from "node:fs";
import { join } from "node:path";
import { performance } from "node:perf_hooks";

const REPO = process.argv[2];
const { instance } = await WebAssembly.instantiate(readFileSync(join(REPO, "target/wasm32-unknown-unknown/release/jiro_wasm.wasm")), {});
const wasm = instance.exports;
const memory = (ptr, len) => new Uint8Array(wasm.memory.buffer, ptr, len);
const bytes = (text) => Uint8Array.from(Buffer.from(text.replace(/^0x/, ""), "hex"));

function masksOf(journal, ticks) {
  const count = (journal[69] << 8) | journal[70];
  const events = [];
  for (let i = 0; i < count; i += 1) {
    const at = 71 + 3 * i;
    events.push({ tick: (journal[at] << 8) | journal[at + 1], mask: journal[at + 2] });
  }
  const masks = [];
  let mask = 0, next = 0;
  for (let t = 0; t < ticks; t += 1) {
    if (events[next]?.tick === t) { mask = events[next].mask; next += 1; }
    masks.push(mask);
  }
  return masks;
}

function pass(level, journal, masks) {
  memory(wasm.input_ptr(), level.length).set(level);
  if (wasm.load_level(level.length) !== 0) throw new Error("load_level");
  memory(wasm.input_ptr(), 32).set(journal.subarray(4, 36));
  if (wasm.start(journal[3], journal[68]) !== 0) throw new Error("start");
  const times = new Float64Array(masks.length);
  for (let t = 0; t < masks.length; t += 1) {
    const t0 = performance.now();
    const code = wasm.tick(masks[t]);
    times[t] = performance.now() - t0;
    if (code !== 0) throw new Error(`tick ${t}: code ${code}`);
  }
  return times;
}

const dir = join(REPO, "vectors/levels");
let worstShare = 0;
console.log("name\tticks\tsum of per-tick minima (ms)\tmean tick (us)\tmax tick (us)\tmax/mean\tmax tick's share of the level\tticks above 10x mean");
for (const name of readdirSync(dir).filter((f) => f.endsWith(".json")).sort()) {
  const v = JSON.parse(readFileSync(join(dir, name), "utf8"));
  const level = bytes(v.level), journal = bytes(v.journal);
  const ticks = v.outcome.ticksUsed;
  const masks = masksOf(journal, ticks);
  pass(level, journal, masks);
  const best = pass(level, journal, masks);
  for (let i = 0; i < 6; i += 1) { const t = pass(level, journal, masks); for (let k = 0; k < t.length; k += 1) if (t[k] < best[k]) best[k] = t[k]; }
  const sum = best.reduce((s, x) => s + x, 0);
  const mean = sum / ticks;
  let max = 0, at = 0, heavy = 0;
  for (let k = 0; k < ticks; k += 1) { if (best[k] > max) { max = best[k]; at = k; } if (best[k] > 10 * mean) heavy += 1; }
  worstShare = Math.max(worstShare, max / sum);
  console.log(`${name.replace(".json", "")}\t${ticks}\t${sum.toFixed(2)}\t${(mean * 1000).toFixed(2)}\t${(max * 1000).toFixed(1)} (tick ${at})\t${(max / mean).toFixed(0)}x\t${(100 * max / sum).toFixed(2)} %\t${heavy}`);
}
console.log(`largest share of a level's play time taken by one tick: ${(100 * worstShare).toFixed(2)} %`);
