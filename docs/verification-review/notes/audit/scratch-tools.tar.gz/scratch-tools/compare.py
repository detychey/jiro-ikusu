import csv, json, sys, glob
A = sys.argv[1]; f = sys.argv[2]
cyc = json.load(open(A + "/data/cycles.json"))
rows = list(csv.DictReader(open(f), delimiter="\t"))
# expected outcomes from the vectors
exp = {}
for d in ("game", "levels"):
    for p in glob.glob("/home/user/jiro-ikusu/vectors/%s/*.json" % d):
        v = json.load(open(p))
        if v.get("kind") != "game": continue
        exp[d + "/" + v["name"]] = v
bad = 0; ratios = []
print("%-38s %10s %10s %7s" % ("vector", "rv32 instr", "r0 user", "ratio"))
for r in rows:
    n = r["name"]; v = exp[n]
    if "outcome" in v:
        o = v["outcome"]
        ok = (int(r["code"]) == 0 and int(r["ticks"]) == o["ticksUsed"] and int(r["claim_bp"]) == o["claimBp"] and int(r["score"]) == o["levelScore"] and int(r["end"]) == o["endReason"])
    else:
        ok = int(r["code"]) == v["error"]
    bad += not ok
    u = cyc.get(n, {}).get("r0_user")
    if u:
        ratios.append(int(r["instructions"]) / u)
    if len(sys.argv) > 3 or n in ("game/commit-at-tick-0", "game/open-field-empty", "game/capture-edge-rectangle", "game/open-field-capture", "game/full-journal", "game/worst-case", "levels/10-worst", "levels/05-worst", "levels/01-synthetic", "game/boss-corridor-b2"):
        print("%-38s %10s %10s %7s %s" % (n, r["instructions"], u, ("%.3f" % (int(r["instructions"]) / u)) if u else "-", "" if ok else "OUTCOME MISMATCH"))
print("outcome mismatches:", bad, "of", len(rows))
print("instr / r0 user cycles: min %.3f max %.3f mean %.3f" % (min(ratios), max(ratios), sum(ratios) / len(ratios)))
tot_i = sum(int(r["instructions"]) for r in rows if r["name"].startswith("levels/"))
tot_u = sum(cyc[r["name"]]["r0_user"] for r in rows if r["name"].startswith("levels/"))
print("gate set: rv32 instr %d, r0 user %d, ratio %.4f" % (tot_i, tot_u, tot_i / tot_u))
